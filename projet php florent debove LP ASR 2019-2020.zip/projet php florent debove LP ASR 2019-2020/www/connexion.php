<?php
//déclare les fichier nécessaires
require_once 'config/init.conf.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'include/function.inc.php';
include_once 'include/header.inc.php';
include_once 'include/menu.inc.php';
/* @var $bdd PDO */

//print_r2($_POST);
//print_r2($_FILES);
//print_r2($_SESSION);

//$_SESSION['result'] = 'ok';

if (isset($_POST['bouton'])) {//si on appuye sur le bouton alors
    //print_r2($_POST);

    $email = $_POST['email'];
    $mdp = sha1($_POST['mdp']);//sha1 permet d'encrypter le mot de passe, peu securisé car facilement decryptable

    $sth = $bdd->prepare("SELECT * "//on selectionne les données contenu dans utilisateur
            . "FROM utilisateur "
            . "WHERE email = :email AND mdp = :mdp");

    $sth->bindValue(':email', $email, PDO::PARAM_STR);//on attribue la valeur voulu au parametre string, sert de securité si les caracteres posent probleme
    $sth->bindValue(':mdp', $mdp, PDO::PARAM_STR);

    $sth->execute();//execute la requete

    if ($sth->rowCount() > 0) {//si il y a plus d'une ligne alors
        //connexion ok
        $donnees = $sth->fetch(PDO::FETCH_ASSOC);

        $sid = $donnees['email'] . time();
        $sid_hache = md5($sid);
        // echo $sid_hache;

        setcookie('sid', $sid_hache, time() + 30000);//on crée un cookie pour la page avec une durée de vie de 30000 secondes

        $sth_update = $bdd->prepare("UPDATE utilisateur "
                . "SET sid = :sid "
                . "WHERE id = :id ");
        $sth_update->bindValue(':sid', $sid_hache, PDO::PARAM_STR);
        $sth_update->bindValue(':id', $donnees['id'], PDO::PARAM_INT);

        $result_connexion = $sth_update->execute();
        // var_dump($sth_update);
        /*         * ************NOTIFICATION*********** */
    if ($result_connexion == TRUE){
            $_SESSION['notification']['result'] = 'success';
            $_SESSION['notification']['message'] = '<b>Felicitations ! </b> Vous êtes connecté.';//indique à l'utilisateur qu'il est connecté
        }else{
            $_SESSION['notification']['result'] = 'danger';
            $_SESSION['notification']['message'] = '<b>Attention !</b> Erreur  ';// indique a l'utilisateur qu'il y a eu une erreur
        }

        /*         * ************NOTIFICATION*********** */
        
        header("Location: index.php");//redirection vers la page d'accueil
        exit();
 }else {
        //connexion refusée
        /*         * *** NOTIFICATIONS **** */
        
        $_SESSION['notification']['result'] = 'danger';
        $_SESSION['notification']['message'] = '<b>Attention !</b> Veuillez vérifier vos identifiant et mot de passe.';//indique à l'itilisateur de verifier ses informations de connexion
        

        header("location: connexion.php");//Redirection vers la page d'accueil

 }

    exit();

} else {
    ?>
    <!DOCTYPE html>
    <html lang="fr"> <!--indique la langue-->

        <?php include_once 'include/header.inc.php'; ?>

        <body>

            <!-- Page Content -->
            <div class="container"><!--permet de mettre le contenu au centre-->
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h1 class="mt-5">Connexion</h1>
                    </div>
                </div>

                <div class="row">
                    <form method="post" enctype='multipart/form-data'action="connexion.php">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" class="form-control" id="email" required >
                        </div> 
                        <div class="form-group">
                            <label for="mdp">Mot de passe</label>
                            <input type="password" name="mdp" class="form-control" id="mdp" required >
                        </div>        

                        <button type="bouton" name="bouton" class="btn btn-primary">Connection</button>
                    </form>

                </div>
            </div>

            <!-- Footer -->
            <?php include_once 'include/footer.inc.php'; ?>
        </body>

    </html>
    <?php
}
?>