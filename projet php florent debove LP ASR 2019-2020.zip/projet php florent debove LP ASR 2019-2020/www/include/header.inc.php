
<head>

    <meta charset="utf-8"> <!--on utilise un jeu de caractere qui est utf-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <!-- on definie les paramettre d'affichage de la page -->
    <meta name="description" content=""> <!-- baliser servant a donner une brève description de notre site(petit commentaire en dessous du site quand on fait une recherche google -->


    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

</head>
