<?php

function pagination($page_courante, $nb_articles_par_page) {//permet de paginer les articles
    $index = ($page_courante - 1) * $nb_articles_par_page;
    return $index;
}
function declareNotification($message, $result) {//permet de créer des notification
    $_SESSION['notification']['message'] = $message;
    $_SESSION['notification']['result'] = $result;
    
    return true;
}
function _nb_total_article($bdd) {//permet de compter le nombre d'articles
    $sth = $bdd->prepare("SELECT COUNT(*) as total_articles "
            . "FROM article "
            . "WHERE publie = :publie");
    $sth->bindValue('publie', 1, PDO::PARAM_BOOL);
    $sth->execute();

    $result = $sth->fetch(PDO::FETCH_ASSOC);

    $total_articles = $result['total_articles'];

    return $total_articles;
}