<?php
require_once 'config/connexion.conf.php'; //on charge le ficher connexion.conf
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
        <a class="navbar-brand">Mon site</a> <!-- titre du site --> 
        <div class="collapse navbar-collapse" id="navbarResponsive"> <!-- creer un bandeau responsive qui s'adapte a la taille de l'ecran --> 
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Index</a>
                    <span class="sr-only">(current)</span>
                    </a>
                </li>
                </li>
                <?php
                if ($connecte == true) {// si l'utilisateur est connecté
                    ?>
                    <li class="nav-item">
                        <a class="nav-link" href="articles.php">Formulaire Articles</a><!-- affiche le lien vers la page de création de formulaire -->
                    </li>
                <?php } ?>
                <li class="nav-item">
                    <a class="nav-link" href="utilisateur.php">Formulaire Utilisateur</a><!-- affiche le lien vers la page de création de compte utilisateur -->
                </li>
                <?php
                if ($connecte == false) {// si l'utilisateur n'est pas connecté
                    ?>
                    <li class="nav-item">
                        <a class="nav-link" href="connexion.php">connection</a><!-- affiche le lien vers la page de connection -->
                    </li>
                <?php } else { ?><!-- sinon -->


                    <li class="nav-item">
                        <a class="nav-link" href="deconnexion.php">deconnection</a> <!-- affiche le lien vers la page de deconnection qui detruira le cookie de l'utilisateur -->
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

