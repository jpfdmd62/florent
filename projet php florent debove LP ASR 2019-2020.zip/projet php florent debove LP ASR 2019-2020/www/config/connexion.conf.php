<?php

/* @var $bdd PDO */
$connecte = false;
if (isset($_COOKIE['sid'])) {//si la connexion est reussi 
    $sid = $_COOKIE['sid'];
    $sth_connexion = $bdd->prepare("SELECT * "
            . "FROM utilisateur "
            . "WHERE sid = :sid");
    $sth_connexion->bindValue(':sid', $sid, PDO::PARAM_STR);
    $sth_connexion->execute();
    if ($sth_connexion->rowCount() > 0) {
        $connecte = TRUE;//connexion devient true
    }
}