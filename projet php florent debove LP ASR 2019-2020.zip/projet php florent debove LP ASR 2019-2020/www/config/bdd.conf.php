<?php

try {
    $bdd = new PDO('mysql:host=localhost;dbname=mon_blog;charset=utf8', 'root'); //on se connecte a MySQL avec le nom d'host, mon_blog en base de donnée et utf-8 en jeu de caractère 
    $bdd->exec("set names utf8");
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Erreur:' . $e->getMessage());//permet d'afficher les erreur lors de l'execution du code
}
?>
