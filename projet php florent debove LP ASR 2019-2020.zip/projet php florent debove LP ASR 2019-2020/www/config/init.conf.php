<?php

session_start(); //
error_reporting(E_ALL);
ini_set("display_error", 1);

define('_nb_articles_par_page_',2);

function print_r2($ma_variable) {
    echo'<pre>';
    print_r($ma_variable);
    echo '</pre>';

    return true;
}

date_default_timezone_set('Europe/Paris');//permet de definir le fuseau horaire

define('_nb_art_par_page', 2);

