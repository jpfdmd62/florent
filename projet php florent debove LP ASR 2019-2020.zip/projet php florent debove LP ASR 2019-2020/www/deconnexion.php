<?php

setcookie('sid', '', -1);// detruit le cookie

header("Location: index.php");
exit();
