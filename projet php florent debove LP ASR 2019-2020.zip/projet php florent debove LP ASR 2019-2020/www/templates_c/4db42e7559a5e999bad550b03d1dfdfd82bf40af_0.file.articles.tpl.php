<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-09 21:53:47
  from 'C:\wamp64\www\templates\articles.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e40715b1d75c7_47572348',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4db42e7559a5e999bad550b03d1dfdfd82bf40af' => 
    array (
      0 => 'C:\\wamp64\\www\\templates\\articles.tpl',
      1 => 1581280864,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e40715b1d75c7_47572348 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- Page Content -->
<div class="container">
    <div class="row">            
        <form method="POST" action="articles.php" enctype="multipart/form-data">
            <?php if ($_smarty_tpl->tpl_vars['action']->value == 'modifier' && !empty($_smarty_tpl->tpl_vars['action']->value)) {?> <!--si on a appuyé sur le bouton modifier alors-->
                <h1 class="mt-5"> Modification d'un article</h1><!-- afficher modifier un article -->
            <?php } else { ?><!--sinon-->
                <h1 class="mt-5"> Ajouter un article</h1><!-- afficher ajouter un article -->
            <?php }?>

            <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $_smarty_tpl->tpl_vars['monarticle']->value['id'];?>
">

            <div class="form-group">
                <label for="titre">Titre: </label>
                <input type="text" class="form-control" id="titre" name="titre" placeholder="Titre" value="<?php echo $_smarty_tpl->tpl_vars['monarticle']->value['titre'];?>
">
            </div>
            <div class="form-group">
                <label for="texte">Contenu:</label>
                <textarea class="form-control" id="texte" name="texte" rows="4"><?php echo $_smarty_tpl->tpl_vars['monarticle']->value['texte'];?>
</textarea>
            </div>
            <div class="form-group">
                <label for="img">Image:</label>
                <input type="file" class="form-control-file" id="img" name="img">
            </div>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="publie" name="publie">
                <label class="form-check-label" for="publie" >Publier ?</label>
            </div>
            <?php if ($_smarty_tpl->tpl_vars['action']->value == 'modifier' && !empty($_smarty_tpl->tpl_vars['action']->value)) {?> <!--si on a appuyé sur le bouton modifier alors-->
                <button type="bouton" class="btn btn-primary" name="bouton" value="modifier">Modifier</button><!-- afficher modifier -->
            <?php } else { ?><!--sinon-->
                <button type="bouton" class="btn btn-primary" name="bouton" value="ajouter">Ajouter</button><!-- affiche ajouter -->
            <?php }?>
        </form>

    </div>

    <!-- Bootstrap core JavaScript -->
    <?php echo '<script'; ?>
 src="vendor/jquery/jquery.slim.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="vendor/bootstrap/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>

</body>

</html>
<?php }
}
