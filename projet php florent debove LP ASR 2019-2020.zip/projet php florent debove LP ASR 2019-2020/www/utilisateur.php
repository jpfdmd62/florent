<?php
require_once 'config/init.conf.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'include/function.inc.php';
include_once 'include/header.inc.php';

/* @var $bdd PDO */

//print_r2($_POST);
//print_r2($_FILES);
//print_r2($_SESSION);

//$_SESSION['result'] = 'ok';

if (isset($_POST['bouton'])) {//si on appuye sur le bouton alors

    //creation des variables
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $mdp = sha1($_POST['mdp']);//crypte le mot de passe

    /* if(isset($_POST['publie'])){
      $publie = 1;
      }else{                              equivaut a ce qu'ily a au dessus
      $publie = 0;
      }
     */

    // prepare a l insertion dans la base de donnée utilisateur
    $sth = $bdd->prepare("INSERT INTO utilisateur "
            . "(nom, prenom, email, mdp)"
            . "VALUES (:nom, :prenom, :email, :mdp)");
    $sth->bindValue(':nom', $nom, PDO::PARAM_STR);
    $sth->bindValue(':prenom', $prenom, PDO::PARAM_STR);
    $sth->bindValue(':email', $email, PDO::PARAM_STR);
    $sth->bindValue(':mdp', $mdp, PDO::PARAM_STR);

    $result_insert_utilisateur = $sth->execute();//execute la requete

    //$id_insert = $bdd->lastInsertId();

    /*     * ************NOTIFICATION*********** */
        
    $message = '<b>Félicitation</b>,compte créé !'; //notification indiquant que le compte est bien ajouté a la bdd, il parviendra a l'utilisateur sur la page index
    $result = 'success'; //indique si l envoi de l article sest bien passé ou non
    
    declareNotification($message, $result);
    
    /*     * ************NOTIFICATION*********** */
    
    
    
    
    
    header("Location: index.php");  //redirection vers la page d'accueil
        exit();// met fin au script
}
    ?>
    <!DOCTYPE html>
    <html lang="fr">

    <?php include_once 'include/header.inc.php'; ?>

        <body>

            <!-- Navigation -->
    <?php include_once 'include/menu.inc.php'; ?>

            <!-- Page Content -->
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h1 class="mt-5">Formulaire utilisateur</h1>
                    </div>
                </div>

                <div class="row">
                    <form method="post" enctype='multipart/form-data'action="utilisateur.php">
                        <div class="form-group">
                            <label for="nom">Nom</label>
                            <input type="text" name="nom" class="form-control" id="nom" required >
                        </div>
                        <div class="form-group">
                            <label for="prenom">Prenom</label>
                            <input type="text" name="prenom" class="form-control" id="prenom" required >
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" class="form-control" id="email" required >
                        </div> 
                        <div class="form-group">
                            <label for="mdp">Mot de passe</label>
                            <input type="password" name="mdp" class="form-control" id="mdp" required >
                        </div>        

                        <button type="bouton" name="bouton" class="btn btn-primary">Créer</button>
                    </form>

                </div>
            </div>



            <!-- Footer -->
    <?php include_once 'include/footer.inc.php'; ?>
        </body>

    </html>
            <?php
       
        ?>