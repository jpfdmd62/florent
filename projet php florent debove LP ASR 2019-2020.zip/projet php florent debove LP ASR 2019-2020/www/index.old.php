<?php

require_once 'config/init.conf.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
require_once('libs/Smarty.class.php');
require_once 'function.inc.php';
include_once 'include/menu.inc.php';

//print_r2($_SESSION);
/* @var $bdd PDO */
/* * **pagination*** */
$page_courante = !empty($_GET['p']) ? $_GET['p'] : 1;

$nb_total_articles = _nb_total_article($bdd);

$nb_total_pages = ceil($nb_total_articles / _nb_art_par_page);

$index = pagination($page_courante, _nb_art_par_page);

/* * **pagination*** */
$sth = $bdd->prepare("SELECT id, "
        . "titre, "
        . "texte, "
        . "DATE_FORMAT(date,'%d/%m/%Y') AS date_fr, "
        . "publie "
        . "FROM article "
        . "WHERE publie = :publie "
        . "LIMIT :index, :nb_art_par_page");

$sth->bindValue(':publie', 1, PDO::PARAM_BOOL);
$sth->bindValue(':index', $index, PDO::PARAM_INT);
$sth->bindValue(':nb_art_par_page', _nb_art_par_page, PDO::PARAM_INT);
$sth->execute();

$tab_article = $sth->fetchAll(PDO::FETCH_ASSOC);

//print_r2($tab_article);
/* foreach ($tab_article as $value){
  echo $value['titre'];
  echo'<br/>';
  } */




$smarty = new Smarty();

$smarty->setTemplateDir('templates/');
$smarty->setCompileDir('templates_c/');
/*
 * $smarty->config_dir   = '/web/www.example.com/guestbook/configs/';
  $smarty->cache_dir    = '/web/www.example.com/guestbook/cache/';
 */


$smarty->assign('tab_article', $tab_article);
$smarty->assign('nb_total_pages', $nb_total_pages);
$smarty->assign('page_courante', $page_courante);

//** un-comment the following line to show the debug console
//$smarty->debugging = true;
include_once 'include/header.inc.php';
$smarty->display('index.tpl');

 $_SESSION['notification']['message'];
isset($_SESSION['notification']);
echo $_SESSION['notification']['message'];
unset($_SESSION['notifications']);

