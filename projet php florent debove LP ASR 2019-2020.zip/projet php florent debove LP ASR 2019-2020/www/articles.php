<?php
//déclare les fichier nécessaires
require_once 'config/init.conf.php';
include_once 'include/function.inc.php';
require_once 'config/bdd.conf.php';
require_once 'config/connexion.conf.php';
include_once 'include/header.inc.php';
require_once('libs/Smarty.class.php');
include_once 'include/menu.inc.php';
include_once 'include/footer.inc.php';

/* @var $bdd PDO */

$monarticle = array("id" => "", "titre" => "", "texte" => "", "date" => "", "publie" => "");//on crée un tableau vide

    $idarticle = $_GET['a'];//on récupere les variable de la page index
    $modifier = $_GET['action'];

if ($modifier == "modifier") {//si on appuie sur le bouton modifier alors on rempli le tableau
    $sth = $bdd->prepare("SELECT id, "//on recupere les donnée contenu dans article
            . "titre, "
            . "texte, "
            . "date, "
            . "publie "
            . "FROM article "
            . "WHERE id = :id ");
    
      $sth->bindValue(":id", $idarticle, PDO::PARAM_INT);//on attribue la valeur voulu au parametre integer
    $sth->execute();
    //on incrémente les données dans le tableau
      $monarticle = $sth->fetch(PDO::FETCH_ASSOC);
      
}

  if (!empty(filter_input(INPUT_POST, 'bouton'))) { //si on a appuyé sur le bouton alos

        $titre = filter_input(INPUT_POST, 'titre');
        $texte = filter_input(INPUT_POST, 'texte');

        $publie = isset($_POST['publie']) ? 1 : 0; //condition ternaire qui signifie que si la checkbox est coché alors publie prend 1 sinon 0

        $date = date('Y-m-d'); //date au format américain ANNEE-MOIS-JOUR
        //echo $date;

        $sth = $bdd->prepare("INSERT INTO article " //prépare la requête d'insertion de l article dans le bdd
                . "(titre, texte, publie, date) "
                . "VALUES (:titre, :texte, :publie, :date)");
        $sth->bindValue(':titre', $titre, PDO::PARAM_STR);
        $sth->bindValue(':texte', $texte, PDO::PARAM_STR);
        $sth->bindValue(':publie', $publie, PDO::PARAM_BOOL);
        $sth->bindValue(':date', $date, PDO::PARAM_STR);

        $sth->execute(); //on exécute la requête, retourne true si il n'y a pas eu de probleme sinon ereur

        $id_article = $bdd->lastInsertId(); //récupère et attribut à $id_article le dernier id entré dans la bdd

        if ($_FILES['img']['error'] == 0) {//si le code de l'image est 0 alors
            move_uploaded_file($_FILES['img']['tmp_name'], 'img/' . $id_article . '.jpg'); //on récupère l'image et on la deplace dans le répertoire img du site avec id  comme nom et avec l extension .jpg
        }

        $message = '<b>Félicitation</b>, votre article est ajouté !'; //notification indiquant que l'article est bien ajouté a la bdd, il parviendra a l'utilisateur sur la page index
        $result = 'success'; //indique si l envoi de l article sest bien passé ou non

        declareNotification($message, $result);

        header("Location: index.php"); //redirection vers la page index.php

        exit(); //on met fin au script
    }

$smarty = new Smarty();

$smarty->setTemplateDir('templates/');
$smarty->setCompileDir('templates_c/');//le fichier tpl et php de la page sont compilé ensemble et ajouté dans templates_c

$smarty->assign('monarticle', $monarticle);
$smarty->assign('action', $modifier);

$smarty->display('articles.tpl');//affiche le template de la page
?>